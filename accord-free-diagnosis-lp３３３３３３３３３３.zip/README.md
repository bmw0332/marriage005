# アコード結婚相談所｜無料個別診断 広告専用LP

X広告からの流入を、**無料個別診断の予約完了**へつなげるための単一目的ページです。
既存トップページ（会社・サービス紹介型）とは別物として、ゼロから設計・実装しています。

- 静的サイト（HTML / CSS / 素のJavaScript）。フレームワーク・ビルドツールなし
- 現在のサーバーへそのままアップロードできます
- 外部Webフォントを読み込みません（端末標準の日本語フォントを使用）

---

## 1. ファイル構成

```
index.html                    新しい広告専用LP（無料個別診断）
service.html                  旧index.html を退避（サービス内容・料金）
thanks.html                   予約完了ページ（noindex）
company.html                  運営会社・プライバシーポリシー・特商法（ほぼ無変更）
terms.html                    利用規約（ほぼ無変更）
robots.txt
sitemap.xml
.htaccess                     無変更
README.md                     このファイル
CRO_TEST_PLAN.md              公開後の改善計画・ヘッドライン候補
assets/css/style.css          LP・thanks共通のスタイル
assets/js/analytics.js        計測タグ読み込み／流入元保持／dataLayer送信
assets/js/timerex-config.js   TimeRex設定（★変更はここだけ）
assets/js/main.js             LPの動作（CTA・FAQ・固定CTA・計測・TimeRex制御）
assets/js/thanks.js           サンクスページの計測
assets/images/logo.webp       既存ロゴ（Base64から分離）
assets/images/ibj.webp        既存IBJ正規加盟店バッジ（Base64から分離）
assets/images/ogp.jpg         LP用OGP画像（新規作成）
assets/images/ogp-service.jpg service.html用OGP（既存ogp.jpgを流用）
assets/images/service-*.webp  service.html用の既存写真（Base64から分離）
docs/README_previous.md       これまでの開発履歴（旧README.md をそのまま保存）
```

---

## 2. 変更ファイル一覧

| ファイル | 区分 | 内容 |
|---|---|---|
| `index.html` | **全面新規** | 広告専用LPへ差し替え。旧内容は `service.html` へ退避 |
| `service.html` | 新規（旧index） | canonical・og:url を `/service.html` へ変更。title・descriptionをサービス内容中心へ変更。ロゴリンクを新トップへ変更。冒頭にLPへの戻り導線を追加。フッターの「無料個別診断」リンクをLPへ変更。Base64画像を`assets/images/`へ分離 |
| `thanks.html` | 新規 | 予約完了ページ。noindex |
| `company.html` | 軽微 | Base64ロゴを`assets/images/logo.webp`へ分離。リンク切れとなる `index.html#consult` を `index.html#booking` へ修正（2箇所） |
| `terms.html` | 軽微 | Base64ロゴを`assets/images/logo.webp`へ分離 |
| `robots.txt` | 軽微 | 変更なし（`thanks.html`はnoindexメタで制御。robotsで拒否するとnoindexが読まれないため、あえて許可しています） |
| `sitemap.xml` | 更新 | `service.html`を追加。lastmodを更新。`thanks.html`は意図的に不掲載 |
| `.htaccess` | **無変更** | |
| `assets/**` | 新規 | CSS・JS・画像 |
| `docs/README_previous.md` | 移動 | 旧README.md（162KBの開発履歴）。消さずに保存しています |

---

## 3. 削除した既存要素一覧

コンバージョンに寄与しない、または広告専用LPの目的から外れると判断して**新LPから外した**ものです。
（`service.html` には残っているため、情報自体は失われていません）

**構成・導線**
- 13セクション構成そのもの（新LPは7セクション＋ヘッダー・フッター）
- ヘッダーのページ内ナビゲーション（強み／支援内容／実績／料金／よくある質問）
- LINE 60秒セルフチェックのCTA（`https://lin.ee/SDYjZsC`）※CTAの一本化のため
- フッターの各種回遊リンク（法定ページとservice.htmlのみに限定）

**セクション**
- 「初めての方でも、無理なく続けられる理由」
- 「結婚を考えている人が、11万人います。」（IBJ会員数訴求）
- 「本番の前に練習し、結果を毎回振り返る。」（支援サイクル5ステップ／支援範囲）
- 「このプログラムを設計した理由」（長文の設計者メッセージ）
- 「かかる費用は、この4つです。」（料金表全体）
- 「向いている方・向いていない方」
- 事例の横スクロールカルーセル（縦読みカード2件へ変更）
- 事例1件（29歳・会社員）※2件に絞る指示のため
- FAQ 21問 → 8問へ削減

**デザイン・演出**
- ネイビー＋ゴールドの高級感基調のトークン一式
- 外部Webフォント（Inter / Noto Sans JP）の読み込み
- スクロール連動のreveal（フェードイン）演出
- ヒーローの大型写真（カフェで会話する男女）
- 女性カウンセラーのストック写真3点
- HTML内のBase64画像（約200KB）

---

## 4. 既存サイトから再利用した事実・素材一覧

**素材**

| 素材 | 出所 | 用途 |
|---|---|---|
| ロゴ（128×128 webp） | 旧index.htmlのBase64 | ヘッダー／フッター／favicon |
| IBJ正規加盟店バッジ（272×96 webp） | 旧index.htmlのBase64 | ヘッダー／信頼要素／フッター |
| TimeRex予約URL | 旧index.html | `https://timerex.net/s/ba.08h_1a1f/83cf8db1` |
| GTMコンテナID | 旧index.html | `GTM-5FZHVHXW` |
| X広告ピクセルID | 旧index.html | `retf6` |
| MetaピクセルID | 旧index.html | `1387328040199947` |
| 既存写真5点 | 旧index.htmlのBase64 | service.html でのみ使用（新LPでは不使用） |

**事実情報（表現を強めず、そのまま、または弱めて掲載）**

- 1年間で男性23名を個別指導／60％以上が交際に進展
- 対象は交際経験がまったくない、または少ない28〜44歳の男性
- 指導はすべてオンライン
- 男性向け婚活支援プログラムを設計し、事業責任者を担当
- 株式会社リクルートの経営企画プロジェクトへの参画経験
- 自身も結婚相談所を利用して配偶者と出会い、その経験が『日経WOMAN』に掲載
- 実績注記（開業前の育成プログラムでの実績である旨／結果には個人差がある旨）
- 支援事例2件（34歳・自営業／38歳・会社員）
- 活動拠点：東京都千代田区・茨城県守谷市（オンライン全国対応）
- IBJ正規加盟店であること

**意図的に強めなかった点**
- 「交際に進展」を「成婚」へ言い換えていません
- 実績数値・経歴・提供範囲・法定情報・IBJとの関係・予約URLは一切変更していません

---

## 5. TimeRex埋め込み（★未対応事項）

添付ZIP内に**TimeRexの正式な埋め込みコードが含まれていなかった**ため、埋め込みコードは作成していません（推測で書くと動作しないうえ、計測も誤ります）。

現在は **外部遷移フォールバック** で公開できる状態です。予約セクションのボタンから予約ページへ遷移し、予約自体は成立します。

### 埋め込みコードを取得したあとの設定手順

`assets/js/timerex-config.js` だけを編集します。HTML・CSS・main.js の変更は不要です。

```js
embed: {
  enabled: true,                       // ← false から true へ
  scriptSrc: 'TimeRexが発行するJSのURL', // ← 管理画面からコピー
  mountAttrs: { 'data-xxx': '...' },    // ← マウント要素に付く data-* をそのまま
  completeCallbackName: 'onBookingComplete', // ← 実際の名称に合わせる
  messageOrigin: 'https://timerex.net',
  height: 760                           // ← レイアウトシフト防止のため実寸に合わせる
}
```

- ウィジェットは `index.html` の `<div id="timerexMount">` に描画されます
- 読み込みは**予約セクションの600px手前に到達した時点、またはCTAクリック時**の遅延読み込みです（初期表示速度を落とさないため）
- 読み込みに失敗した場合は自動でフォールバック表示へ戻ります
- `enabled: true` にすると、CTAクリック時はページ内スクロール＋ウィジェット読み込みに変わります

### 埋め込みなしでのCTA挙動

`assets/js/main.js` 冒頭の `LP_CONFIG.ctaBehaviorWithoutEmbed` で切り替えられます。

- `'scroll'`（**現在の設定**）… CTAは予約セクションへスクロール。セクション内のボタンで予約ページへ
- `'redirect'` … CTAクリックで直接TimeRexへ遷移

ご指示のうち「CTAを押しても別サイトへ直ちに移動させない（◆12）」を優先し、既定を `'scroll'` にしています。1行の変更で切り替えられます。

---

## 6. TimeRex管理画面で必要な設定（要対応）

管理画面を操作できないため、**変更は行っていません**。以下は推奨設定です。

### 予約フォームの項目

| 項目 | 推奨 | 理由 |
|---|---|---|
| 氏名 | **必須** | 本人確認に必要 |
| メールアドレス | **必須** | 予約確認・当日URL送付に必要 |
| 現在、最も困っていること | **任意** | 事前準備の質が上がる。選択式なら入力負担が小さい |

「現在、最も困っていること」の選択肢：
`そもそも会えない` / `2回目につながらない` / `LINEが途切れる` / `原因が分からない` / `その他`

### 必須にしない項目（予約完了率を下げます）

電話番号、住所、年収、詳細な婚活歴、長文の相談内容、入会意思、結婚希望時期、複数ページの事前アンケート

### そのほかの推奨設定

1. **予約完了後のリダイレクト先を `https://accord-marriage.jp/thanks.html` に設定**
   → 外部遷移で予約した場合、これが `booking_complete` を計測できる唯一の経路です。**最優先で設定してください。**
2. 予約可能枠を平日夜・土日にも確保（枠不足は日程選択離脱の主因です）
3. リマインドメールを前日と当日に送信（予約完了→面談実施の歩留まり対策）
4. 予約受付の締切を「開始2時間前」程度に（当日枠を捨てない）
5. 所要時間の表示を60分に統一

---

## 7. 計測イベント一覧

すべて `dataLayer` へ送信します。全イベントに流入元パラメータ（`utm_source` / `utm_medium` / `utm_campaign` / `utm_content` / `utm_term` / `twclid` / `fbclid` / `gclid` / `lp_variant`）が自動で付きます。

| イベント名 | 発火タイミング | 主なパラメータ |
|---|---|---|
| `lp_view` | LP表示時 | `page_type` |
| `lp_cta_click` | CTAクリック時 | `cta_position` / `cta_text` |
| `booking_section_view` | 予約セクションが初めて50％以上表示された時 | — |
| `timerex_widget_loaded` | TimeRexウィジェットの読み込み完了時 | `load_trigger` |
| `booking_start` | 日程選択／予約入力の開始時（1回のみ） | `booking_method` |
| `booking_complete` | 予約完了時（**1セッション1回のみ**） | `booking_method` / `booking_id` |
| `thank_you_view` | thanks.html表示時 | `page_type` |
| `faq_open` | FAQが開かれた時 | `faq_question` |
| `timerex_widget_error` | ウィジェット読み込み失敗時 | — |

`cta_position` の値は次の6種類に統一しています。
`header` / `hero` / `deliverables` / `proof` / `final` / `mobile_sticky`

**CTAクリックは予約完了ではありません。** `lp_cta_click` をコンバージョンに設定しないでください。

### 二重送信の防止

`booking_complete` は `sessionStorage` のフラグで1セッション1回に制限しています。
埋め込みウィジェットから遷移した場合はLP側で送信済みのため、`thanks.html` では送信しません。
外部遷移で予約した場合は `thanks.html` が唯一の送信箇所になります。サンクスページを再読込しても二重送信しません（動作確認済み）。

---

## 8. GTM側で必要な設定（未実施・要対応）

GTMコンテナを操作できないため、**タグ設定は行っていません。** 以下が必要な設定です。

### トリガー（カスタムイベント）

`lp_view` / `lp_cta_click` / `booking_section_view` / `timerex_widget_loaded` / `booking_start` / `booking_complete` / `thank_you_view` / `faq_open`

### データレイヤー変数

`cta_position` / `cta_text` / `booking_method` / `booking_id` / `load_trigger` / `faq_question` /
`utm_source` / `utm_medium` / `utm_campaign` / `utm_content` / `utm_term` / `twclid` / `fbclid` / `gclid` / `lp_variant`

### 広告成果との連携（`booking_complete` トリガー）

| 連携先 | 設定 |
|---|---|
| GA4 | `generate_lead`（見込み客獲得）としてイベント送信 → GA4管理画面でキーイベントに設定 |
| X広告 | X Universal Website Tag のイベントタグ。X広告管理画面で「予約完了」イベントを作成し、Event IDを設定 |
| Meta広告 | Metaピクセルの `Schedule` または `Lead` イベント |

`booking_start` は補助指標（マイクロコンバージョン）としてGA4のみに送るのが安全です。広告の最適化対象は `booking_complete` に一本化してください。

### 既存タグの扱い

`assets/js/analytics.js` に既存の設定をそのまま引き継いでいます。

| タグ | 現在の状態 |
|---|---|
| GTM `GTM-5FZHVHXW` | LP・thanks 双方で読み込み |
| GA4 `G-N2QDZ2RSWV` | GTM側で設定済みのため、コード側は空欄 |
| Microsoft Clarity | GTM側で設定済みのため、コード側は空欄 |
| X広告ピクセル `retf6` | コード側で直接読み込み |
| Metaピクセル `1387328040199947` | コード側で直接読み込み |

X・Metaピクセルは、GTM側へ移設すれば `analytics.js` の該当IDを空欄にするだけで停止できます（GTMへの一本化を推奨します）。

---

## 9. 実施した動作確認結果

ローカルHTTPサーバー＋Chromium（Playwright）で確認しました。

### 表示幅

| 幅 | 横スクロール | ページ全長 | 390×844換算 |
|---|---|---|---|
| 320px | なし | 10,043px | 11.9画面 |
| 375px | なし | 9,179px | 10.9画面 |
| **390px** | なし | **8,981px** | **10.6画面** |
| 414px | なし | 8,619px | 10.2画面 |
| 768px | なし | 7,594px | 9.0画面 |
| 1024px | なし | 7,083px | 8.4画面 |
| 1280px | なし | 7,000px | 8.3画面 |
| 1440px | なし | 7,000px | 8.3画面 |

### 機能

| 確認項目 | 結果 |
|---|---|
| 320〜1440pxで横スクロールなし | OK |
| ファーストビューにCTAがある（375px：CTA下端429px／補足文下端484px、いずれも812px以内） | OK |
| 主CTAの高さ 54px（PC 60px）／横幅ほぼ全幅 | OK |
| 文章が途中で切れない | OK |
| 固定ヘッダー・固定CTAが本文を隠さない（重なり判定0件） | OK |
| 各CTAが `#booking` へ移動する | OK |
| TimeRexフォールバックが動作する | OK |
| 予約完了イベントが一度だけ送信される（サンクス再読込でも増えない） | OK |
| thanks.html が表示される／noindex | OK |
| UTM・twclid が予約URLまで保持される | OK |
| FAQがマウス・キーボード（Enter）で開閉する／`aria-expanded` が切り替わる | OK |
| 法定ページへのリンクが動く | OK |
| service.html が表示される | OK |
| 画像がすべて表示される | OK |
| JavaScriptエラー・コンソールエラー | 0件 |
| リンク切れ | 0件 |
| OGP・canonical が正しい | OK |
| index.html と service.html の canonical が重複していない | OK |
| sitemap.xml が更新されている | OK |
| robots.txt から必要ページが拒否されていない | OK |
| H1が1つだけ／見出し階層の飛びなし | OK |
| FAQの `aria-expanded` `aria-controls` `role="region"` | OK |
| タップ領域44×44px以上 | OK（スキップリンクはフォーカス時に44px） |

### 表示速度（実測ではなく構成上の根拠）

Lighthouseを実行できる環境がないため、スコアは測定していません。以下は構成から言えることです。

- **LCP要素はH1テキスト**（ファーストビューに画像を置いていないため）。ヒーロー画像による遅延がありません
- 外部Webフォントの読み込みが**0件**（旧サイトはGoogle Fonts 2ファミリーを読み込み）
- HTML内Base64画像を全廃（旧index.html 298KB → 新index.html 約20KB）
- JavaScriptライブラリ0件、スライダー0件。自前JSは合計約17KB（未圧縮）
- 全JSが `defer`。TimeRexは遅延読み込み
- 全画像に `width` / `height` 指定。ファーストビュー外は `loading="lazy"`
- CLS対策：ウィジェット読み込み前に高さを確保、フォント切替なし、アニメーションでのレイアウト移動なし
- `prefers-reduced-motion` に対応

**公開後に PageSpeed Insights で実測してください。** 目標未達となりうる主因は、GTM・X・Metaの各タグ（サードパーティJS）です。LP自体の構成では目標値を満たせる想定です。

---

## 10. 未対応事項・要確認事項

### 【確定済み】担当者名

担当者名は **坂本 早貴** で確定しています（2026-09-05 ご指示）。
当初の指示にあった「清水 直人」は使用していません。既存の法定ページと一致した状態です。

| 箇所 | 記載 |
|---|---|
| 新LP 担当者セクション | 坂本 早貴 |
| `company.html` 運営会社 | 通信販売業務責任者：坂本 早貴 |
| `company.html` 特定商取引法に基づく表記 | 通信販売業務責任者：坂本 早貴 |
| `company.html` プライバシーポリシー | 通信販売業務責任者：坂本 早貴 |

LP上の肩書は「アコード結婚相談所／男性向け婚活支援プログラム設計・担当」としています。
`company.html` の「通信販売業務責任者」は法定表記のための役割名であり、LPの担当者紹介としては読み手に伝わりにくいため、そのままは使用していません。
「代表」など別の肩書を表示する場合は、正式な役職名をご指定ください（`index.html` の `.advisor__role` 1箇所）。

変更が必要な場合の該当箇所は `index.html` の `.advisor__name` と、`assets/js/main.js` の `LP_CONFIG.advisorAlt`（写真のalt用）の2箇所です。

### 【未提供】TimeRexの正式な埋め込みコード

推測での実装は行っていません。第5章の手順で設定してください。埋め込みがなくても予約は成立します。
埋め込みが設定されるまで、`timerex_widget_loaded` と、ウィジェット経由の `booking_start` は発火しません。

### 【未提供】担当者本人の実写写真

写真が添付されていないため、**写真なしで成立するレイアウト**にしています。
既存の女性カウンセラー写真および生成画像は、担当者写真として使用していません。

写真を入手したら `assets/images/advisor.webp`（推奨96×96px以上の正方形）を配置し、
`assets/js/main.js` 冒頭の `LP_CONFIG.advisorPhoto` に `'assets/images/advisor.webp'` を設定してください。
自動で枠付きの写真が差し込まれます（未設定時は画像リクエストが発生しません）。

### 【未提供】広告クリエイティブ画像

ご指示に「添付した広告画像」とありましたが、アップロードされたのは `marriage002-main.zip` のみでした。
広告と完全に同じビジュアルを再現できないため、**広告のメッセージ（会えない／2回目につながらない／LINEが途切れる）をHTML・CSSで再構成**しています。
広告画像をいただければ、ファーストビューとOGPの表現を広告に寄せて調整します。

### 【未実施】GTM・広告管理画面の設定

第8章のとおり、コンテナを操作できないため未実施です。設定したという報告はしていません。

### 【未実施】Lighthouse計測

実行環境がないため未計測です。第9章に構成上の根拠を記載しています。

### 【判断事項】本文の最小文字サイズ

ご指示は「本文は原則16px以上」でしたが、カード内の補足文は15px、注記は13〜13.5pxとしています。
16pxに統一するとページ全長が11画面を超え、「8〜11画面」の指示と両立しなかったためです。
本文の基準サイズ（`body`）は16px、リード文15.5px、チェックリスト15pxで、いずれも行間1.8を確保しています。

### 【判断事項】スマートフォンのヘッダーCTA文言

幅320pxでロゴ・IBJバッジ・CTAを同時に収めるため、スマートフォンのヘッダーCTAのみ「**空き日程を確認**」と短縮しています（768px以上では「無料で空き日程を確認する」）。
`aria-label` には正式文言を設定しているため、読み上げ環境では統一されています。

---

## 11. アップロード手順

### GitHub へアップロードする場合（重要）

ブラウザの「Add file → Upload files」で**ファイルを個別に選択すると、フォルダ階層が失われます。**
`assets/css/style.css` が `style.css` として直下に置かれ、CSS・JS・画像がすべて404になります。

**正しい方法：**

1. ZIPを解凍する
2. 解凍してできた中身（`index.html` などのファイルと **`assets` フォルダ**）をすべて選択
3. GitHubのアップロード画面へ**そのままドラッグ&ドロップ**する（フォルダごとドラッグすれば階層が保たれます）
4. アップロード一覧に `assets/css/style.css` のように**スラッシュ付きのパス**が表示されていることを確認してからコミット

コマンドで行う場合：

```
git add .
git commit -m "無料個別診断LPへ差し替え"
git push
```

**アップロード後の確認：** リポジトリのファイル一覧に `assets` フォルダが表示されていること。表示されていなければ階層が失われています。

`.htaccess` と `.nojekyll` はドット始まりのため、ブラウザのドラッグ&ドロップでは選択されないことがあります。
GitHub Pages では両方とも無くて問題ありません（`.htaccess` は本番のApacheサーバーでのみ使用します）。

### GitHub Pages のサブパスで公開する場合

`https://<ユーザー名>.github.io/<リポジトリ名>/` のようなサブパスでもそのまま動作します（ページ内リンク・素材パスはすべて相対パスのため）。

ただし次の3点は本番ドメイン（`https://accord-marriage.jp/`）を指したままです。

- `canonical` / `og:url`
- `og:image`
- `sitemap.xml` / `robots.txt` の記載URL

**検証用として公開する場合はこのままで問題ありません**（本番と重複ページ扱いになりません）。
GitHub Pages を本番として運用する場合のみ、上記4箇所をGitHub PagesのURLへ書き換えてください。

## 12. 公開手順

1. 現在のサーバーの `index.html` を**バックアップ**
2. 本ZIPの中身をドキュメントルートへアップロード（`assets/` ディレクトリを含む）
3. `https://accord-marriage.jp/` で新LPが表示されることを確認
4. `https://accord-marriage.jp/service.html` で旧トップが表示されることを確認
5. Search Console でサイトマップを再送信
6. TimeRex管理画面で**予約完了後のリダイレクト先を `thanks.html` に設定**（第6章）
7. GTMでトリガーとタグを設定（第8章）
8. テスト予約を1件行い、`booking_complete` → `thank_you_view` が1回ずつ記録されることを確認
9. X広告の配信を開始

**8番のテスト予約は、広告配信前に必ず実施してください。** 計測が動いていない状態で配信すると、改善の判断材料が残りません。
